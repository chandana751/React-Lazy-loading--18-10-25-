import React from 'react';

function Personalinfo() {
  return <div>This is Personal Info Page</div>;
}

export default Personalinfo;
